﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace MyConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                using (ServiceHost sh = new ServiceHost(typeof(ClassLibrary1.MyService)))
                { 
                    sh.Open();
                    Console.WriteLine("Service Hosted");
                    Console.ReadLine();
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
