﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsServiceTemp
{
    public class FileWatcher
    {
        // Create a new FileSystemWatcher and set its properties.
        FileSystemWatcher watcher = new FileSystemWatcher();

        public FileWatcher(string path)
        {
            watcher.Path = path;

            // Watch both files and subdirectories.
            watcher.IncludeSubdirectories = true;

            // Watch for all changes specified in the NotifyFilters
            //enumeration.
            watcher.NotifyFilter = NotifyFilters.Attributes |
            NotifyFilters.CreationTime |
            NotifyFilters.DirectoryName |
            NotifyFilters.FileName |
            NotifyFilters.LastAccess |
            NotifyFilters.LastWrite |
            NotifyFilters.Security |
            NotifyFilters.Size;

            // Watch csv files.
            watcher.Filter = "*.csv";

            // Add event handlers.
            //watcher.Changed += new FileSystemEventHandler(OnChanged);
            watcher.Created += new FileSystemEventHandler(OnChanged);
            //watcher.Deleted += new FileSystemEventHandler(OnChanged);

            //Start monitoring.
            watcher.EnableRaisingEvents = true;
        }

        // Define the event handlers.
        public static void OnChanged(object source, FileSystemEventArgs e)
        {
            // Specify what is done when a file is changed.
            Logger.Log(String.Format("{0}, with path {1} has been stored to database.", e.Name, e.FullPath));

            StreamReader reader = new StreamReader(File.OpenRead(e.Name));

            //string vara1, vara2, vara3, vara4;

            string line = "";

            //reading header row
            while (!reader.EndOfStream)
                line = reader.ReadLine();

            while (!reader.EndOfStream)
            {
                line = reader.ReadLine();
                if (!String.IsNullOrWhiteSpace(line))
                {
                    string[] values = line.Split(',');
                    if (values.Length >= 4)
                    {
                        DataTable dt = new DataTable();
                        dt.Clear();
                        dt.Columns.Add("a");
                        dt.Columns.Add("b");
                        dt.Columns.Add("c");
                        dt.Columns.Add("d");
                        DataRow dr = dt.NewRow();
                        dr["a"] = values[0];
                        dr["b"] = values[1];
                        dr["c"] = values[2];
                        dr["d"] = values[3];
                        dt.Rows.Add(dr);
                        string connetionString = null;
                        SqlConnection cnn;
                        connetionString = "Data Source='192.168.20.114';Initial Catalog='ayushi';Persist Security Info=True;User ID='ivp';Password='ivp@123'";
                        cnn = new SqlConnection(connetionString);
                        using (SqlCommand cmd = new SqlCommand("Insert_tmpTable"))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Connection = cnn;
                            cmd.Parameters.AddWithValue("@tblCustomers", dt);
                            cnn.Open();
                            cmd.ExecuteNonQuery();
                            cnn.Close();
                        }
                    }
                }
            }
        }
    }
}
