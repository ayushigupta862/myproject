﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace WindowsServiceTemp
{

    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();          
        }

        protected override void OnStart(string[] args)
        {
            string path = ConfigurationManager.AppSettings["watchPath"];
            FileWatcher myFileWatcher = new FileWatcher(path);
        }

        protected override void OnStop()
        {
        }
    }
    
}

